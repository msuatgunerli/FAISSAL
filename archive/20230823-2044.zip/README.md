# FAISSAL

Document QA Chatbot using LLaMA 2, FAISS, and LangChain